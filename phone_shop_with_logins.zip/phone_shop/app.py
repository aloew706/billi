import re
from datetime import date

from flask import Flask, abort, flash, redirect, render_template, request, session, url_for

import config
import db

app = Flask(__name__, static_folder="static")
app.secret_key = config.SECRET_KEY
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"

COLORS = {
    "черный": ("#3a3a3c", "#111"), "белый": ("#fafafa", "#d8d8dc"), "синий": ("#5b8def", "#1f4fb5"),
    "серый": ("#a1a1a6", "#636366"), "зеленый": ("#7bd88f", "#2f8f4e"), "зелёный": ("#7bd88f", "#2f8f4e"),
    "фиолетовый": ("#b18cf0", "#6b3fc4"), "красный": ("#ff6b6b", "#b3202a"), "золотой": ("#f1d9a8", "#c29a4d"),
    "розовый": ("#f9a8c9", "#d6568a"), "голубой": ("#8fd3f4", "#3b9ed6"),
}


@app.template_filter("gradient")
def gradient(color):
    a, b = COLORS.get((color or "").strip().lower(), ("#c7c7cc", "#8e8e93"))
    return f"linear-gradient(160deg, {a}, {b})"


@app.template_filter("money")
def money(v):
    return "" if v is None else f"{float(v):,.0f}".replace(",", " ") + " ₽"


@app.template_filter("badge")
def badge(status):
    s = (status or "").lower()
    if "отмен" in s:
        return "bad"
    if "доставлен" in s:
        return "ok"
    return "warn" if s else ""


def digits(s):
    return re.sub(r"\D", "", s or "")[-10:]


@app.context_processor
def inject():
    return {"role": session.get("role"), "uname": session.get("name"), "path": request.path}


def need(role):
    if session.get("role") != role:
        flash("Войдите в систему", "error")
        abort(redirect(url_for("login")))


@app.errorhandler(Exception)
def on_error(e):
    from werkzeug.exceptions import HTTPException
    if isinstance(e, HTTPException):
        return e
    return render_template("error.html", message=str(e)), 500


# ---------- каталог (открыт всем) ----------
@app.get("/")
def catalog():
    q = request.args.get("q", "").strip()
    brand = request.args.get("brand", "").strip()
    brands = {b["Код_марки"]: b for b in db.rows("марки")}
    items = []
    for p in db.rows("телефоны"):
        b = brands.get(p.get("код_марки"), {})
        items.append({
            "brand": b.get("название_марки", ""), "model": p.get("модель"), "storage": p.get("памятьГБ"),
            "ram": p.get("ОЗУГБ"), "color": p.get("цвет"), "description": p.get("описание"),
        })
    all_brands = sorted({i["brand"] for i in items if i["brand"]})
    shown = [i for i in items if (not brand or i["brand"] == brand) and (not q or q.lower() in (i["model"] or "").lower())]
    return render_template("catalog.html", items=shown, brands=all_brands, q=q, brand=brand)


# ---------- вход / выход ----------
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        try:
            # Миграция выполняется автоматически при первом открытии формы входа.
            db.ensure_login_table()
        except Exception as e:
            return render_template("login.html", error=f"Не удалось подготовить таблицу логинов: {e}")
    if request.method == "POST":
        lg = request.form.get("login", "").strip()
        pw = request.form.get("password", "").strip()
        if lg == config.ADMIN_LOGIN and pw == config.ADMIN_PASSWORD:
            session.clear()
            session.update(role="admin", name="Администратор")
            return redirect(url_for("admin"))
        try:
            # При первом обращении создаёт таблицу [Логины], связь с [покупатели]
            # и переносит существующие учётные записи в виде хешей паролей.
            db.ensure_login_table()
            buyer = db.authenticate_buyer(lg, pw)
            if buyer:
                session.clear()
                session.update(role="user", name=buyer["name"], buyer_id=buyer["buyer_id"])
                return redirect(url_for("orders"))
        except Exception as e:
            return render_template("login.html", error=f"Ошибка таблицы логинов: {e}", login=lg)
        return render_template("login.html", error="Неверный логин или пароль", login=lg)
    return render_template("login.html")


@app.post("/logout")
def logout():
    session.clear()
    return redirect(url_for("catalog"))


# ---------- заказы покупателя ----------
@app.get("/orders")
def orders():
    need("user")
    phones = {p["Код_телефона"]: p for p in db.rows("телефоны")}
    delivery = {d.get("Код_заказа"): d for d in db.rows("доставка")}
    out = []
    for o in db.rows("заказы"):
        if o.get("Код_покупателя") != session["buyer_id"]:
            continue
        d = delivery.get(o["Код_заказа"], {})
        out.append({
            "id": o["Код_заказа"], "model": phones.get(o.get("Код_телефона"), {}).get("модель"),
            "date": o.get("Дата_заказа"), "qty": o.get("Количество"), "sum": o.get("Сумма"),
            "pay": o.get("Способ_оплаты"), "delivery": d.get("Способ_доставки"), "status": d.get("Статус"),
        })
    out.sort(key=lambda x: x["id"], reverse=True)
    return render_template("orders.html", orders=out)


# ---------- управление (только админ) ----------
def option_list(table):
    pk = db.SCHEMA[table]["pk"]
    out = {}
    for r in db.rows(table):
        if table == "марки":
            label = r.get("название_марки")
        elif table == "телефоны":
            label = r.get("модель")
        elif table in ("покупатели", "продавцы"):
            label = r.get("ФИО")
        elif table == "заказы":
            label = f"№{r[pk]} от {r.get('Дата_заказа') or '—'}"
        else:
            label = str(r.get(pk))
        out[r[pk]] = label
    return out


@app.get("/admin")
def admin():
    need("admin")
    t = request.args.get("t", "марки")
    if t not in db.SCHEMA:
        abort(404)
    meta = db.SCHEMA[t]
    rows = db.rows(t)
    fk_labels, fk_options = {}, {}
    for f in meta["fields"]:
        if f.get("fk"):
            fk_options[f["name"]] = option_list(f["fk"])
    cols = [meta["pk"]] + [f["name"] for f in meta["fields"]]
    return render_template("admin.html", schema=db.SCHEMA, t=t, meta=meta, rows=rows, cols=cols,
                           fk_options=fk_options, today=date.today().isoformat())


@app.post("/admin/add/<t>")
def admin_add(t):
    need("admin")
    if t not in db.SCHEMA:
        abort(404)
    try:
        new_id = db.insert(t, request.form.to_dict())
        flash(f"Добавлено в Access (код {new_id})", "ok")
    except ValueError as e:
        flash(str(e), "error")
    except Exception as e:
        flash(f"Ошибка записи в Access: {e}", "error")
    return redirect(url_for("admin", t=t))


if __name__ == "__main__":
    print("Сайт: http://127.0.0.1:5000")
    app.run(host="127.0.0.1", port=5000, debug=False)
