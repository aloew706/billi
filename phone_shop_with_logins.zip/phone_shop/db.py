"""Работа с базой Access через ODBC (pyodbc)."""
import datetime
import decimal

import pyodbc

import config

# Описание таблиц: имена как в вашем файле Access.
# kind: text / int / money / date ; fk — ссылка на другую таблицу ; req — обязательное поле
SCHEMA = {
    "марки": {
        "title": "Марки", "pk": "Код_марки",
        "fields": [
            {"name": "название_марки", "label": "Название марки", "kind": "text", "req": True},
            {"name": "страна", "label": "Страна", "kind": "text", "req": False},
        ],
    },
    "цвет": {
        "title": "Цвета", "pk": "Код_Цвета",
        "fields": [{"name": "Цвет", "label": "Цвет", "kind": "text", "req": True}],
    },
    "память": {
        "title": "Память", "pk": "Код_памяти",
        "fields": [{"name": "память", "label": "Объем памяти, ГБ", "kind": "int", "req": True}],
    },
    "телефоны": {
        "title": "Телефоны", "pk": "Код_телефона",
        "fields": [
            {"name": "код_марки", "label": "Марка", "kind": "int", "fk": "марки", "req": True},
            {"name": "модель", "label": "Модель", "kind": "text", "req": True},
            {"name": "памятьГБ", "label": "Память, ГБ", "kind": "int", "req": True},
            {"name": "ОЗУГБ", "label": "ОЗУ, ГБ", "kind": "int", "req": True},
            {"name": "цвет", "label": "Цвет", "kind": "text", "req": False},
            {"name": "описание", "label": "Описание", "kind": "text", "req": False},
        ],
    },
    "покупатели": {
        "title": "Покупатели", "pk": "Код_Покупателя",
        "fields": [
            {"name": "ФИО", "label": "ФИО", "kind": "text", "req": True},
            {"name": "номер_телефона", "label": "Номер телефона", "kind": "text", "req": True},
            {"name": "email", "label": "Email", "kind": "text", "req": True},
            {"name": "Адрес", "label": "Адрес", "kind": "text", "req": False},
        ],
    },
    "продавцы": {
        "title": "Продавцы", "pk": "Код_Сотрудника",
        "fields": [
            {"name": "ФИО", "label": "ФИО", "kind": "text", "req": True},
            {"name": "Должность", "label": "Должность", "kind": "text", "req": False},
        ],
    },
    "заказы": {
        "title": "Заказы", "pk": "Код_заказа",
        "fields": [
            {"name": "Код_покупателя", "label": "Покупатель", "kind": "int", "fk": "покупатели", "req": True},
            {"name": "Код_телефона", "label": "Телефон", "kind": "int", "fk": "телефоны", "req": True},
            {"name": "Код_сотрудника", "label": "Продавец", "kind": "int", "fk": "продавцы", "req": True},
            {"name": "Дата_заказа", "label": "Дата заказа", "kind": "date", "req": True},
            {"name": "Количество", "label": "Количество", "kind": "int", "req": True},
            {"name": "Сумма", "label": "Сумма, ₽", "kind": "money", "req": True},
            {"name": "Способ_оплаты", "label": "Способ оплаты", "kind": "text", "req": False},
        ],
    },
    "доставка": {
        "title": "Доставка", "pk": "Код_доставки",
        "fields": [
            {"name": "Код_заказа", "label": "Заказ", "kind": "int", "fk": "заказы", "req": True},
            {"name": "Способ_доставки", "label": "Способ доставки", "kind": "text", "req": True},
            {"name": "Адрес_доставки", "label": "Адрес доставки", "kind": "text", "req": False},
            {"name": "Дата_отправки", "label": "Дата отправки", "kind": "date", "req": False},
            {"name": "Дата_получения", "label": "Дата получения", "kind": "date", "req": False},
            {"name": "Статус", "label": "Статус", "kind": "text", "req": False},
        ],
    },
}

INT_TYPES = {"INTEGER", "LONG", "SHORT", "SMALLINT", "BYTE", "TINYINT", "COUNTER", "INT", "BIGINT"}
NUM_TYPES = {"CURRENCY", "DOUBLE", "SINGLE", "REAL", "FLOAT", "DECIMAL", "NUMERIC"}
DATE_TYPES = {"DATETIME", "DATE", "TIMESTAMP"}
BOOL_TYPES = {"BIT", "YESNO"}


def connect():
    # Проверяем базу и драйвер до попытки подключения, чтобы показать точную причину.
    import os
    import struct

    db_path = os.path.abspath(config.DB_PATH)
    if not os.path.isfile(db_path):
        raise RuntimeError(
            f"Файл базы Access не найден: {db_path}. "
            "Положите файл .accdb рядом с config.py или исправьте DB_PATH в config.py."
        )

    access_driver = next(
        (name for name in pyodbc.drivers()
         if name.lower().startswith("microsoft access driver") and "accdb" in name.lower()),
        None,
    )
    if not access_driver:
        bits = struct.calcsize("P") * 8
        available = ", ".join(pyodbc.drivers()) or "нет"
        raise RuntimeError(
            "Windows не зарегистрировала ODBC-драйвер Microsoft Access (*.mdb, *.accdb). "
            f"Разрядность текущего Python: {bits}-bit. Установите Microsoft Access Database "
            f"Engine той же разрядности ({bits}-bit), затем полностью перезапустите IDE/терминал. "
            f"Сейчас доступны драйверы: {available}."
        )

    conn_str = f"DRIVER={{{access_driver}}};DBQ={db_path};"
    try:
        return pyodbc.connect(conn_str, autocommit=False)
    except pyodbc.Error as e:
        raise RuntimeError(
            "Драйвер Access найден, но базу открыть не удалось. Проверьте, что файл "
            "не открыт в режиме монопольного доступа и у пользователя есть права на папку. "
            f"Подробности: {e}"
        )


def _column_types(conn, table):
    cur = conn.cursor()
    return {r.column_name: (r.type_name or "").upper() for r in cur.columns(table=table)}


def _last_id(cur):
    cur.execute("SELECT @@IDENTITY")
    return cur.fetchone()[0]


def _coerce(value, type_name, kind):
    """Приводим значение из формы к типу поля в Access."""
    if value is None or (isinstance(value, str) and value.strip() == ""):
        return None
    t = (type_name or "").upper()
    if t in INT_TYPES or (not t and kind == "int"):
        return int(str(value).strip())
    if t in NUM_TYPES or (not t and kind == "money"):
        return decimal.Decimal(str(value).strip().replace(",", "."))
    if t in DATE_TYPES or (not t and kind == "date"):
        return datetime.datetime.strptime(str(value).strip(), "%Y-%m-%d")
    if t in BOOL_TYPES:
        return str(value).strip().lower() in ("1", "true", "да", "on")
    return str(value).strip()


def _jsonable(v):
    if isinstance(v, (datetime.datetime, datetime.date)):
        return v.strftime("%Y-%m-%d")
    if isinstance(v, decimal.Decimal):
        return float(v)
    return v


def rows(table):
    """Все строки таблицы в виде списка словарей."""
    meta = SCHEMA[table]
    conn = connect()
    try:
        cur = conn.cursor()
        cur.execute(f"SELECT * FROM [{table}]")
        names = [d[0] for d in cur.description]
        data = [{n: _jsonable(v) for n, v in zip(names, r)} for r in cur.fetchall()]
    finally:
        conn.close()
    data.sort(key=lambda r: (r.get(meta["pk"]) is None, r.get(meta["pk"])))
    return data


def insert(table, form):
    """Добавляет строку в таблицу Access. Возвращает новый код."""
    meta = SCHEMA[table]
    fields = meta["fields"]
    for f in fields:
        if f["req"] and str(form.get(f["name"], "")).strip() == "":
            raise ValueError(f"Заполните поле «{f['label']}»")
    conn = connect()
    try:
        types = _column_types(conn, table)
        cols, vals = [], []
        for f in fields:
            if f["name"] in form:
                try:
                    v = _coerce(form[f["name"]], types.get(f["name"], ""), f["kind"])
                except (ValueError, decimal.InvalidOperation):
                    raise ValueError(f"Неверное значение в поле «{f['label']}»")
                if v is None and not f["req"]:
                    continue
                cols.append(f["name"])
                vals.append(v)
        if not cols:
            raise ValueError("Нет данных для добавления")
        sql = (
            f"INSERT INTO [{table}] ({', '.join('[' + c + ']' for c in cols)}) "
            f"VALUES ({', '.join('?' for _ in cols)})"
        )
        cur = conn.cursor()
        cur.execute(sql, vals)
        new_id = _last_id(cur)
        conn.commit()
        return int(new_id) if new_id is not None else None
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def ensure_login_table():
    """Создаёт таблицу учётных записей, связь с покупателями и переносит старые входы.

    Для уже существующих покупателей логином становится email, первоначальным
    паролем — последние 10 цифр номера телефона (как в прежней версии сайта).
    Пароль хранится только в виде безопасного хеша.
    """
    from werkzeug.security import generate_password_hash

    conn = connect()
    try:
        cur = conn.cursor()
        try:
            cur.execute("SELECT TOP 1 [Код_Логина] FROM [Логины]")
            cur.fetchone()
        except pyodbc.Error:
            conn.rollback()
            cur = conn.cursor()
            cur.execute(
                "CREATE TABLE [Логины] ("
                "[Код_Логина] COUNTER CONSTRAINT [PK_Логины] PRIMARY KEY, "
                "[Код_Покупателя] LONG NOT NULL, "
                "[Логин] TEXT(255) NOT NULL, "
                "[Хеш_Пароля] TEXT(255) NOT NULL, "
                "[Дата_Создания] DATETIME, "
                "[Активен] YESNO)"
            )
            conn.commit()

        # Уникальность логина и связь 1:1 с покупателем.
        for sql in (
            "CREATE UNIQUE INDEX [UX_Логины_Логин] ON [Логины] ([Логин])",
            "CREATE UNIQUE INDEX [UX_Логины_Покупатель] ON [Логины] ([Код_Покупателя])",
            "ALTER TABLE [Логины] ADD CONSTRAINT [FK_Логины_Покупатели] "
            "FOREIGN KEY ([Код_Покупателя]) REFERENCES [покупатели] ([Код_Покупателя])",
            "ALTER TABLE [телефоны] ADD CONSTRAINT [FK_Телефоны_Марки] "
            "FOREIGN KEY ([код_марки]) REFERENCES [марки] ([Код_марки])",
            "ALTER TABLE [заказы] ADD CONSTRAINT [FK_Заказы_Покупатели] "
            "FOREIGN KEY ([Код_покупателя]) REFERENCES [покупатели] ([Код_Покупателя])",
            "ALTER TABLE [заказы] ADD CONSTRAINT [FK_Заказы_Телефоны] "
            "FOREIGN KEY ([Код_телефона]) REFERENCES [телефоны] ([Код_телефона])",
            "ALTER TABLE [заказы] ADD CONSTRAINT [FK_Заказы_Продавцы] "
            "FOREIGN KEY ([Код_сотрудника]) REFERENCES [продавцы] ([Код_Сотрудника])",
            "ALTER TABLE [доставка] ADD CONSTRAINT [FK_Доставка_Заказы] "
            "FOREIGN KEY ([Код_заказа]) REFERENCES [заказы] ([Код_заказа])",
        ):
            try:
                cur.execute(sql)
                conn.commit()
            except pyodbc.Error:
                # Индекс/связь уже могли быть созданы при предыдущем запуске.
                conn.rollback()
                cur = conn.cursor()

        cur.execute(
            "SELECT [Код_Покупателя], [email], [номер_телефона] FROM [покупатели]"
        )
        buyers = cur.fetchall()
        for buyer_id, email, phone in buyers:
            login_name = (email or "").strip().lower()
            password = "".join(ch for ch in str(phone or "") if ch.isdigit())[-10:]
            if not login_name or not password:
                continue
            cur.execute(
                "SELECT COUNT(*) FROM [Логины] WHERE [Код_Покупателя]=? OR [Логин]=?",
                (buyer_id, login_name),
            )
            if cur.fetchone()[0]:
                continue
            cur.execute(
                "INSERT INTO [Логины] ([Код_Покупателя], [Логин], [Хеш_Пароля], [Дата_Создания], [Активен]) "
                "VALUES (?, ?, ?, ?, ?)",
                (buyer_id, login_name, generate_password_hash(password), datetime.datetime.now(), True),
            )
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def authenticate_buyer(login_name, password):
    """Проверяет учётную запись из [Логины] и возвращает данные покупателя."""
    from werkzeug.security import check_password_hash

    login_name = (login_name or "").strip().lower()
    password = password or ""
    conn = connect()
    try:
        cur = conn.cursor()
        cur.execute(
            "SELECT [Логины].[Код_Покупателя], [Логины].[Хеш_Пароля], [Логины].[Активен], "
            "[покупатели].[ФИО] "
            "FROM [Логины] INNER JOIN [покупатели] "
            "ON [Логины].[Код_Покупателя]=[покупатели].[Код_Покупателя] "
            "WHERE [Логины].[Логин]=?",
            (login_name,),
        )
        row = cur.fetchone()
        if not row or not row[2]:
            return None
        stored_hash = row[1] or ""
        valid = check_password_hash(stored_hash, password)
        if not valid:
            # Совместимость со старыми паролями-номерами телефонов.
            normalized = "".join(ch for ch in password if ch.isdigit())[-10:]
            valid = bool(normalized) and check_password_hash(stored_hash, normalized)
        if not valid:
            return None
        return {"buyer_id": row[0], "name": row[3] or login_name}
    finally:
        conn.close()
