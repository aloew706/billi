"""Работа с базой Access через ODBC (pyodbc)."""
import datetime
import decimal

import pyodbc

import config

# Описание таблиц: имена как в вашем файле Access.
# kind: text / int / money / date ; fk — ссылка на другую таблицу ; req — обязательное поле
SCHEMA = {
    "марки": {
        "title": "Марки", "pk": "Код_марки",
        "fields": [
            {"name": "название_марки", "label": "Название марки", "kind": "text", "req": True},
            {"name": "страна", "label": "Страна", "kind": "text", "req": False},
        ],
    },
    "цвет": {
        "title": "Цвета", "pk": "Код_Цвета",
        "fields": [{"name": "Цвет", "label": "Цвет", "kind": "text", "req": True}],
    },
    "память": {
        "title": "Память", "pk": "Код_памяти",
        "fields": [{"name": "память", "label": "Объем памяти, ГБ", "kind": "int", "req": True}],
    },
    "телефоны": {
        "title": "Телефоны", "pk": "Код_телефона",
        "fields": [
            {"name": "код_марки", "label": "Марка", "kind": "int", "fk": "марки", "req": True},
            {"name": "модель", "label": "Модель", "kind": "text", "req": True},
            {"name": "памятьГБ", "label": "Память, ГБ", "kind": "int", "req": True},
            {"name": "ОЗУГБ", "label": "ОЗУ, ГБ", "kind": "int", "req": True},
            {"name": "цвет", "label": "Цвет", "kind": "text", "req": False},
            {"name": "описание", "label": "Описание", "kind": "text", "req": False},
        ],
    },
    "покупатели": {
        "title": "Покупатели", "pk": "Код_Покупателя",
        "fields": [
            {"name": "ФИО", "label": "ФИО", "kind": "text", "req": True},
            {"name": "номер_телефона", "label": "Номер телефона", "kind": "text", "req": True},
            {"name": "email", "label": "Email", "kind": "text", "req": True},
            {"name": "Адрес", "label": "Адрес", "kind": "text", "req": False},
        ],
    },
    "продавцы": {
        "title": "Продавцы", "pk": "Код_Сотрудника",
        "fields": [
            {"name": "ФИО", "label": "ФИО", "kind": "text", "req": True},
            {"name": "Должность", "label": "Должность", "kind": "text", "req": False},
        ],
    },
    "заказы": {
        "title": "Заказы", "pk": "Код_заказа",
        "fields": [
            {"name": "Код_покупателя", "label": "Покупатель", "kind": "int", "fk": "покупатели", "req": True},
            {"name": "Код_телефона", "label": "Телефон", "kind": "int", "fk": "телефоны", "req": True},
            {"name": "Код_сотрудника", "label": "Продавец", "kind": "int", "fk": "продавцы", "req": True},
            {"name": "Дата_заказа", "label": "Дата заказа", "kind": "date", "req": True},
            {"name": "Количество", "label": "Количество", "kind": "int", "req": True},
            {"name": "Сумма", "label": "Сумма, ₽", "kind": "money", "req": True},
            {"name": "Способ_оплаты", "label": "Способ оплаты", "kind": "text", "req": False},
        ],
    },
    "доставка": {
        "title": "Доставка", "pk": "Код_доставки",
        "fields": [
            {"name": "Код_заказа", "label": "Заказ", "kind": "int", "fk": "заказы", "req": True},
            {"name": "Способ_доставки", "label": "Способ доставки", "kind": "text", "req": True},
            {"name": "Адрес_доставки", "label": "Адрес доставки", "kind": "text", "req": False},
            {"name": "Дата_отправки", "label": "Дата отправки", "kind": "date", "req": False},
            {"name": "Дата_получения", "label": "Дата получения", "kind": "date", "req": False},
            {"name": "Статус", "label": "Статус", "kind": "text", "req": False},
        ],
    },
}

INT_TYPES = {"INTEGER", "LONG", "SHORT", "SMALLINT", "BYTE", "TINYINT", "COUNTER", "INT", "BIGINT"}
NUM_TYPES = {"CURRENCY", "DOUBLE", "SINGLE", "REAL", "FLOAT", "DECIMAL", "NUMERIC"}
DATE_TYPES = {"DATETIME", "DATE", "TIMESTAMP"}
BOOL_TYPES = {"BIT", "YESNO"}


def connect():
    conn_str = (
        r"DRIVER={Microsoft Access Driver (*.mdb, *.accdb)};"
        f"DBQ={config.DB_PATH};"
    )
    try:
        return pyodbc.connect(conn_str, autocommit=False)
    except pyodbc.Error as e:
        raise RuntimeError(
            "Не удалось открыть базу Access. Проверьте путь DB_PATH в config.py, "
            "что файл не открыт в режиме монопольного доступа, и что установлен "
            "драйвер Microsoft Access Database Engine (той же разрядности, что и Python). "
            f"Подробности: {e}"
        )


def _column_types(conn, table):
    cur = conn.cursor()
    return {r.column_name: (r.type_name or "").upper() for r in cur.columns(table=table)}


def _last_id(cur):
    cur.execute("SELECT @@IDENTITY")
    return cur.fetchone()[0]


def _coerce(value, type_name, kind):
    """Приводим значение из формы к типу поля в Access."""
    if value is None or (isinstance(value, str) and value.strip() == ""):
        return None
    t = (type_name or "").upper()
    if t in INT_TYPES or (not t and kind == "int"):
        return int(str(value).strip())
    if t in NUM_TYPES or (not t and kind == "money"):
        return decimal.Decimal(str(value).strip().replace(",", "."))
    if t in DATE_TYPES or (not t and kind == "date"):
        return datetime.datetime.strptime(str(value).strip(), "%Y-%m-%d")
    if t in BOOL_TYPES:
        return str(value).strip().lower() in ("1", "true", "да", "on")
    return str(value).strip()


def _jsonable(v):
    if isinstance(v, (datetime.datetime, datetime.date)):
        return v.strftime("%Y-%m-%d")
    if isinstance(v, decimal.Decimal):
        return float(v)
    return v


def rows(table):
    """Все строки таблицы в виде списка словарей."""
    meta = SCHEMA[table]
    conn = connect()
    try:
        cur = conn.cursor()
        cur.execute(f"SELECT * FROM [{table}]")
        names = [d[0] for d in cur.description]
        data = [{n: _jsonable(v) for n, v in zip(names, r)} for r in cur.fetchall()]
    finally:
        conn.close()
    data.sort(key=lambda r: (r.get(meta["pk"]) is None, r.get(meta["pk"])))
    return data


def insert(table, form):
    """Добавляет строку в таблицу Access. Возвращает новый код."""
    meta = SCHEMA[table]
    fields = meta["fields"]
    for f in fields:
        if f["req"] and str(form.get(f["name"], "")).strip() == "":
            raise ValueError(f"Заполните поле «{f['label']}»")
    conn = connect()
    try:
        types = _column_types(conn, table)
        cols, vals = [], []
        for f in fields:
            if f["name"] in form:
                try:
                    v = _coerce(form[f["name"]], types.get(f["name"], ""), f["kind"])
                except (ValueError, decimal.InvalidOperation):
                    raise ValueError(f"Неверное значение в поле «{f['label']}»")
                if v is None and not f["req"]:
                    continue
                cols.append(f["name"])
                vals.append(v)
        if not cols:
            raise ValueError("Нет данных для добавления")
        sql = (
            f"INSERT INTO [{table}] ({', '.join('[' + c + ']' for c in cols)}) "
            f"VALUES ({', '.join('?' for _ in cols)})"
        )
        cur = conn.cursor()
        cur.execute(sql, vals)
        new_id = _last_id(cur)
        conn.commit()
        return int(new_id) if new_id is not None else None
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
